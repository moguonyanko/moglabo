This is practical math library.
