#!/usr/bin/python3
# -*- coding: utf-8 -*-

import http.server

http.server.test(HandlerClass=http.server.CGIHTTPRequestHandler)


